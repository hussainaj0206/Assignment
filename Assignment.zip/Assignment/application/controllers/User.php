<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

class User extends CI_Controller {

    public function __construct() {
        parent::__construct(); 
        $this->load->library('session');
        $this->load->model('user_model', 'user');
        $this->load->helper('url_helper');
    }

    //---------Controller method to load the user register view-----------------//
    public function register() {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[users.username]', array('required' => 'Please enter the username', 'is_unique' => 'Username already exists'));
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('retypePassword', 'Password Confirmation', 'required|matches[password]');
        if ($this->form_validation->run() == FALSE) {//-------If validation fails load the same page with error mesaage--------//
            $this->load->view('user/register');
        } else {//------else call the controller method------------//
            $this->register_update();
        }
    }

    //---------Controller method to register a new user-----------------//
    public function register_update() {
        $userData = array();
        $userData['username'] = $this->input->post('username');
        $userData['email'] = $this->input->post('email');
        $userData['password'] = md5($this->input->post('password'));
        $this->user->insert_user($userData);
        $this->session->set_flashdata('register_info', 'User Registered Successfully');
        redirect('index.php/user/login');
    }

    //---------Controller method to load the user login view-----------------//
    public function login() {
        $this->load->view('user/login');
    }
    //---------Controller method post user log in-----------------//
    public function login_post() {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('username', 'Username', 'callback_user_exists_check');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->login();
        } else {
            $flag = $this->user->login_user($username, $password);//-------flag is returned true if username and password is valid-----------//
            if ($flag == true) {
                $sess_data['username'] = $username;
                $sess_data['password'] = $password;
                $this->session->set_userdata($sess_data);
                $this->session->set_flashdata('login_success', 'You are successfully logged in');
                redirect('home');
            } else {
                $this->session->set_flashdata('invalid_credentials', 'Username and password does not match');
                $this->load->view('user/login');
            }
        }
    }
    //---------Controller method to load home view-----------------//
    public function home() {
        $username = $this->session->userdata('username');
        if (isset($username)) {
            $this->load->view('templates/header');
            $this->load->view('user/home');
        } else {
            $this->session->set_flashdata('login_error', 'Please login to view this page.');
            redirect('login');
        }
    }
    //---------Callback method to check whether user exists or not-----------------//
    function user_exists_check($user) {
        $flag = $this->user->user_exists($user);
        if ($flag == false) {
            $this->form_validation->set_message('user_exists_check', 'User does not exist.Please register first');
            return $flag;
        }
    }
    //---------Controller method to logout user from the system-----------------//
    public function logout() {
        $this->session->sess_destroy();
        redirect('login');
    }

}

?>