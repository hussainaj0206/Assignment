<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

class Book extends CI_Controller {

    public function __construct() {
        parent::__construct(); //Constructor of its parent class (CI_Controller)
        $this->load->helper('form');
        $this->load->library('session');
        $this->load->model('book_model', 'book'); //Loads the model, so it can be used in all other methods in this controller
        $this->load->helper('url_helper'); //URL Helper Functions
    }
    
    //---------Controller method to display the list of books-----------------//
    public function book_list() {
        $username = $this->session->userdata('username');
        if (isset($username)) {
            $data['books'] = $this->book->get_books();
            $data['title'] = 'Books List';
            $this->load->view('templates/header', $data);
            $this->load->view('book/book_list', $data);
        } else {
            $this->session->set_flashdata('login_error', 'Please login to view this page.');
            redirect('login');
        }
    }
    
    //---------Controller method to issue a book-----------------//
    public function issue_book($id) {
        $this->book->issue_book($id);
        $this->book_list();
    }
    
    //---------Controller method to return a book-----------------//
    public function return_book($slug) {
        $this->book->return_book($slug);
        $this->book_list();
    }
}
?>