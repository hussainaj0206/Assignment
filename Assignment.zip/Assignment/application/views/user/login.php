<?php
echo validation_errors('<div class="alert alert-danger">', '</div>');
if ($this->session->flashdata('invalid_credentials')) {
    echo '<div class="alert alert-danger">' . $this->session->flashdata('invalid_credentials') . '</div>';
}if ($this->session->flashdata('register_info')) {
    echo '<div class="alert alert-register">' . $this->session->flashdata('register_info') . '</div>';
}if ($this->session->flashdata('login_error')) {
    echo '<div class="alert alert-danger">' . $this->session->flashdata('login_error') . '</div>';
}
$attributes = array('class' => 'form-signin');
echo form_open('login_post', $attributes); //creates a new form with the tag <form>, but with the difference it already set the action with the correct route.
?>
<head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/styles.css">
    <script   src="https://code.jquery.com/jquery-3.1.1.js" ></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style type="text/css">
        body
        {
            background-image: url(<?php echo base_url('/images/backg.jpg'); ?>);
        }
        h1 {
            color: darkblue;
            /*background-color: cyan;*/
            font-size: 45px;
            font-weight: normal;
            margin: 15px 15px 50px 0;
            padding: 14px 15px 10px 15px;
            text-align : center;
            font-family: "SIMPSON";
        }
        h2 {
            color: darkblue;
            font-size: 35px;
            font-weight: normal;
            margin: -33px 15px 50px 0;
            padding: 40px 40px 40px 40px;
            text-align : center;
            font-family: "SIMPSON";
        }.input-group .form-control{
            height:50px;
        }.alert-danger {    
            background-repeat: no-repeat;
            border-color: #dca7a7;
            text-align: center;
            font-size: 20px;
        }.alert-register {    
            border:0px solid;
            text-align: center;
            font-size: 30px;
            background-color: darkturquoise;

        }
    </style>

</head>
<body>
    <h1>Welcome</h1>
    <div class="container" style="text-align:center;">
        <h2>Please Login</h2>
        <div class="input-group" style="margin: 0 auto">
            <?php
            $attributes = array(
                'class' => 'sr-only'
            );
            echo form_label('Username', 'username', $attributes);
            $data = array(
                'name' => 'username',
                'id' => 'username',
                'class' => 'form-control',
                'placeholder' => 'Username'
                    //'required'      => 'required'
            );
            echo form_input($data);
            ?>

            <?php
            $attributes = array(
                'class' => 'sr-only'
            );
            echo form_label('Password', 'inputPassword', $attributes);
            $data = array(
                'type' => 'password',
                'name' => 'password',
                'id' => 'inputPassword',
                'class' => 'form-control',
                'placeholder' => 'Password'
                    //'required'      => 'required'
            );
            echo form_input($data);
            $data = array(
                'class' => 'btn btn-lg btn-primary btn-block',
                'value' => 'Login'
            );
            echo form_submit($data);
            ?>
            <a class="btn btn-lg btn-primary btn-block" href="<?php echo site_url(); ?>register">Register</a>
            <?php echo form_close(); ?>
        </div>
    </div>
</body>