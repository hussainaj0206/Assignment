<?php
$attributes = array('class' => 'form-signin');
echo validation_errors('<div class="alert alert-danger">', '</div>');
echo form_open('register', $attributes);
?>
<head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/styles.css">
    <script   src="https://code.jquery.com/jquery-3.1.1.js" ></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style type="text/css">
        body
        {
            /*background-color : aquamarine;*/
            background-image: url(<?php echo base_url('/images/backg.jpg'); ?>);
        }
        h2 {
            color: darkblue;
            font-size: 35px;
            font-weight: normal;
            margin: 15px 15px 50px 0;
            padding: 40px 40px 40px 40px;
            text-align : center;
            font-family: "SIMPSON";
        }.alert-danger {    
            background-repeat: no-repeat;
            border-color: #dca7a7;
            text-align: center;
            font-size: 20px;
        }
    </style>

</head>
<div class="container">
    <h2>Please Register</h2>
    <?php
    $attributes = array(
        'class' => 'sr-only'
    );
    echo form_label('Username', 'username', $attributes);
    $data = array(
        'name' => 'username',
        'id' => 'username',
        'class' => 'form-control',
        'placeholder' => 'Username'
            //'required'      => 'required'
    );
    echo form_input($data);
    ?>

    <?php
    $attributes = array(
        'class' => 'sr-only'
    );
    echo form_label('Email address', 'inputEmail', $attributes);

    $data = array(
        'type' => 'email',
        'name' => 'email',
        'id' => 'inputEmail',
        'class' => 'form-control',
        'placeholder' => 'Email address'
            //'required'      => 'required'
    );
    echo form_input($data);

    $attributes = array(
        'class' => 'sr-only'
    );
    echo form_label('Password', 'inputPassword', $attributes);
    $data = array(
        'type' => 'password',
        'name' => 'password',
        'id' => 'inputPassword',
        'class' => 'form-control',
        'placeholder' => 'Password'
            //'required'      => 'required'
    );
    echo form_input($data);

    $attributes = array(
        'class' => 'sr-only'
    );
    echo form_label('Password Again', 'inputPassword', $attributes);
    $data = array(
        'type' => 'password',
        'name' => 'retypePassword',
        'id' => 'inputPassword',
        'class' => 'form-control',
        'placeholder' => 'Password Confirmation'
            //'required'      => 'required'
    );
    echo form_input($data);

    $data = array(
        'class' => 'btn btn-lg btn-primary btn-block',
        'value' => 'Register'
    );
    echo form_submit($data);
    ?>
    <a class="btn btn-lg btn-primary btn-block" href="<?php echo site_url(); ?>login">Login</a>
</div>
<?php echo form_close(); ?>