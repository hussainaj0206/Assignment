<?php
if ($this->session->flashdata('login_success')) {
    echo '<div class="alert alert-login">' . $this->session->flashdata('login_success') . '</div>';
}
?>
<head>
    <style type="text/css">
        body
        {
            /*background-color : aquamarine;*/
            background-image: url(<?php echo base_url('/images/backg.jpg'); ?>);
        }.alert-login {    
            border:0px solid;
            text-align: center;
            font-size: 40px;
            background-color: darkturquoise;

        }
    </style>
</head>

<body>
    <div style="text-align: center;margin-top: 57px;">
        <h3 style="font-size: 30px;">Please click on below button to view books list</h3>
        <button id="books_list" style="font-size: 25px;">View</button>
    </div>

    <script type="text/javascript">
        document.getElementById("books_list").onclick = function () {
            location.href = "<?php echo site_url('book_list'); ?>";
        };
    </script>
</body>
