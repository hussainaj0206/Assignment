<head>
    <style type="text/css">
        body
        {
            background-image: url(<?php echo base_url('/images/backg.jpg'); ?>);
        }h1 {
            color: darkviolet;
            /*background-color: cyan;*/
            font-size: 45px;
            font-weight: normal;
            margin: 0px  2px 51px 0;
            padding: 14px 15px 10px 15px;
            text-align : center;
            font-family: "SIMPSON";
        }td{
            width:200px;
            height:74px;
            font-size: 22px;
            color: maroon;
            font-family: sans-serif;
            border: 2px solid black;

        }th{
            width:255px;
            height:74px;
            font-size: 30px;
            border: 2px solid black;

        }.button{
            font-size: 20px;
        }table {
            border-collapse: collapse;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Books List</h1>
    <table align='center' border="1">
        <tr align='center'>
        <h3><th>Book Id</th></h3>
        <h3><th>Book Name</th></h3>
        <h3><th>Book Author</th></h3>
        <h3><th>Issue/Return</th></h3>
    </tr>
    <?php
    $i = 1;
    foreach ($books as $book_item) {
        //print_r($book_item);
        ?>
        <tr align='center'>
            <td><?php echo $book_item['id']; ?><input type="hidden" name="title" value="<?php echo $book_item['id']; ?>" /></td>
            <td><?php echo $book_item['book_name']; ?><input type="hidden" name="text" value="<?php echo $book_item['book_name']; ?>"/> </td>
            <td><?php echo $book_item['book_author']; ?><input type="hidden" name="text" value="<?php echo $book_item['book_author']; ?>"/> </td>
            <td>
                <?php if ($book_item['book_availability'] == 1) { ?>
                    <button class='button' onclick="issueBook(this);" id='issue' value="<?php echo $book_item['id']; ?>">Issue</button>
                <?php } else { ?>
                    <button class='button' onclick="returnBook(this);" id='return' value="<?php echo $book_item['id']; ?>">Return</button>
                <?php } ?>
            </td>
        </tr>

        <script type="text/javascript">
            function issueBook(d) {
                var id = d.value;
                var url = "<?php echo site_url('book/issue_book/'); ?>";
                var completeUrl = url + id;
                //alert(completeUrl);
                location.href = completeUrl;
            }
            function returnBook(d) {
                var id = d.value;
                var url = "<?php echo site_url('book/return_book/'); ?>";
                var completeUrl = url + id;
                location.href = completeUrl;
            }
        </script>

        <?php
        $i++;
    }
    ?>
</table>
<div style="text-align: center;margin-top: 57px;">
    <button id="home" style="font-size: 25px;">Home</button>
</div>
<script type="text/javascript">
    document.getElementById("home").onclick = function () {
        location.href = "<?php echo site_url('home'); ?>";
    };
</script>
</body>