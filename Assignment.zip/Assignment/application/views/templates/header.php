<html>
    <head>
        <title>Books Listing</title>
        <style>
            .header{
                text-align: center;
                padding:45px;
                position: relative;
            }
            .header h1{
                margin:20px;
            }
            .logoutBtn{
                position: absolute;
                right: 50px;
                top: 5px;
                font-size: 28px;
                color: coral;
            }
            .logoutBtn.hide{
                display:none;
            }
            .logoutBtn.show{
                right: 50px;
                top: 40px;
                font-size: 28px;
                color: coral;
                display:block;
            }img{
                height:28px;
                width:25px; 
            }

        </style>
    </head>
    <body>
        <div class="header">
            <a class="logoutBtn" id="logout" href="<?php echo site_url(); ?>logout"><img src ='<?php echo base_url('/images/logout.png'); ?>'>Logout</a>
        </div>


