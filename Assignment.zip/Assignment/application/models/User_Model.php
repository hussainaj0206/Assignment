<?php

class User_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
    //---------Model to insert new user in database-----------------//
    public function insert_user($userData = array()) {
        $insert = $this->db->insert('users', $userData);
        if (mysqli_errno() == 1062) {
            echo "User already exist";
        } else {
            return $insert;
        }
    }
    //---------Model to set the flag when user logs in-----------------//
    public function login_user($username, $password) {
        $query = $this->db->query("SELECT * FROM users WHERE username='$username' AND password=md5('$password')");
        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
    //---------Model to check whether user exists or not-----------------//
    public function user_exists($user) {
        $this->db->where('username', $user);
        $query = $this->db->get('users');
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

}
