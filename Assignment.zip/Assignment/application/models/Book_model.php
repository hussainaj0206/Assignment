<?php

class Book_model extends CI_Model {

    public function __construct() {
        $this->load->database();
    }
    
    //---------Model to get the list of books-----------------//
    function get_books() {
        $query = $this->db->get('book_info');
        if ($query !== FALSE && $query->num_rows() > 0) {
            $books = $query->result_array();
            return $books;
        } else {
            return false;
        }
    }
    //---------Model to issue a book and update the availability of book in database to 0-----------------//
    function issue_book($book_id) {
        $this->db->where('id', $book_id);
        $this->db->update('book_info', array('book_availability' => 0));
        return true;
    }
    //---------Model to return a book and update the availability of book in database to 1-----------------//
    function return_book($book_id) {
        $this->db->where('id', $book_id);
        $this->db->update('book_info', array('book_availability' => 1));
        return true;
    }

}
